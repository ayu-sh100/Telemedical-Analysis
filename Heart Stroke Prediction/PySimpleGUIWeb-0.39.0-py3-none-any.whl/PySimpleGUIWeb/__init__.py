name = "PySimpleGUIWeb"
from .PySimpleGUIWeb import *
